import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

@Component({
  selector: 'app-trip-add',
  imports: [FormsModule],
  templateUrl: './trip-add.html',
  styleUrl: './trip-add.css'
})
export class TripAdd {
  trip: Trip = {
    code: '',
    name: '',
    image: '',
    description: '',
    length: '',
    start: '',
    resort: '',
    perPerson: ''
  };

  constructor(
    private router: Router,
    private tripData: TripData
  ) {}

  onSubmit(): void {
    this.tripData.addTrip(this.trip).subscribe({
      next: () => this.router.navigate(['']),
      error: (err) => console.error(err)
    });
  }
}