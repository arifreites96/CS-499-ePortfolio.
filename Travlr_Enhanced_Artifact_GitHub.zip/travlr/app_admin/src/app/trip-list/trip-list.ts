import { Component, OnInit } from '@angular/core';
import { NgFor } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';
import { TripCard } from '../trip-card/trip-card';

@Component({
  selector: 'app-trip-list',
  standalone: true,
  imports: [NgFor, RouterLink, TripCard],
  templateUrl: './trip-list.html',
  styleUrl: './trip-list.css'
})
export class TripList implements OnInit {
  trips: Trip[] = [];

  constructor(private tripData: TripData) {}

  ngOnInit(): void {
    this.tripData.getTrips().subscribe({
      next: (trips) => this.trips = trips,
      error: (err) => console.error(err)
    });
  }
}