export interface Trip {
  code: string;
  name: string;
  image: string;
  description: string;
  length: string;
  start: string;
  resort: string;
  perPerson: string;
}