import { Routes } from '@angular/router';
import { TripList } from './trip-list/trip-list';
import { TripAdd } from './trip-add/trip-add';
import { TripEdit } from './trip-edit/trip-edit';

export const routes: Routes = [
  { path: '', component: TripList },
  { path: 'add-trip', component: TripAdd },
  { path: 'edit-trip/:code', component: TripEdit }
];