import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

@Component({
  selector: 'app-trip-edit',
  imports: [FormsModule],
  templateUrl: './trip-edit.html',
  styleUrl: './trip-edit.css'
})
export class TripEdit implements OnInit {
  trip!: Trip;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private tripData: TripData
  ) {}

  ngOnInit(): void {
    const code = this.route.snapshot.paramMap.get('code')!;

    this.tripData.getTrip(code).subscribe({
      next: (trip) => this.trip = trip,
      error: (err) => console.error(err)
    });
  }

  onSubmit(): void {
    this.tripData.updateTrip(this.trip).subscribe({
      next: () => this.router.navigate(['']),
      error: (err) => console.error(err)
    });
  }
}