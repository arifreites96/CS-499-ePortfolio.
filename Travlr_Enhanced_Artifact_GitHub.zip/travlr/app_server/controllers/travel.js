const fs = require('fs');

const rawData = fs.readFileSync('./data/trips.json', 'utf8');

console.log('FILE CONTENTS:');
console.log(rawData);
console.log('LENGTH:', rawData.length);

const trips = JSON.parse(rawData);

const travel = (req, res) => {
  res.render('travel', {
    title: 'Travlr Getaways',
    trips
  });
};

module.exports = {
  travel
};