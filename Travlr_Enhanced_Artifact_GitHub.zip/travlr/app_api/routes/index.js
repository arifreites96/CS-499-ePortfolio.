const express = require('express');
const router = express.Router();
const passport = require('passport');

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

const auth = passport.authenticate('jwt', { session: false });

router.post('/register', authController.register);
router.post('/login', authController.login);

router
  .route('/trips')
  .get(tripsController.tripsList)
  .post(auth, tripsController.tripsAddTrip);

router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindByCode)
  .put(auth, tripsController.tripsUpdateTrip)
  .delete(auth, tripsController.tripsDeleteTrip);

module.exports = router;