const express = require('express');
const path = require('path');
const hbs = require('hbs');
const passport = require('passport');

require('./app_server/models/db');
require('./app_api/config/passport');

const app = express();

app.use(passport.initialize());

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(__dirname));

const travelRouter = require('./app_server/routes/travel');
const apiRouter = require('./app_api/routes/index');

app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

app.use('/travel', travelRouter);
app.use('/api', apiRouter);

const port = 3000;

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});