const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

require('./app_server/models/trips');

const Trip = mongoose.model('trips');

const dbURI = 'mongodb://127.0.0.1:27017/travlr';

mongoose.connect(dbURI);

mongoose.connection.on('connected', async () => {
    console.log('Connected to MongoDB');

    try {
        const filePath = path.join(__dirname, 'data', 'trips.json');
        const tripsData = JSON.parse(fs.readFileSync(filePath, 'utf8'));

        await Trip.deleteMany({});
        await Trip.insertMany(tripsData);

        console.log('Trips imported successfully!');
        console.log(`${tripsData.length} trips added.`);
    } catch (err) {
        console.error('Import failed:', err);
    } finally {
        mongoose.connection.close();
    }
});